#!/usr/bin/env bash
python3 /home/syko/FluxPath/scripts/fluxpath_orca_post.py "$1"
